# Bade Bhai Travels

A single-page demo interface for Bade Bhai Travels — live bus tracking, journey planning, and an AI-assisted route search, styled around the brand's navy, teal, and sunset-orange logo palette.

**Interactive extras:**
- **Language switcher** (top-right) — English, Tamil (தமிழ்), Telugu (తెలుగు), Hindi (हिंदी). Switches all page copy and remembers the choice for next visit.
- **"Get more from every journey" plans section** — a ₹99/month plan shown with the original ₹100 struck through, plus a demo "Subscribe" button (no real payment is taken).
- **Soft blue light theme**, with a larger, clearer logo in the nav bar.
- **"Share your experience" section** — visitors can leave a star rating and comment. Since this is a static site with no backend, entries are saved in the visitor's own browser (`localStorage`), so they'll see their own comments on return visits, but comments aren't shared between different visitors' devices. To make comments truly shared across everyone, you'd need a small backend or a service like Firebase/Supabase — happy to help wire that up if you want it.

## Run it locally

Just open `index.html` in any browser. No build step, no dependencies to install.

## Deploy on GitHub Pages

1. Create a new repository on GitHub (e.g. `bade-bhai-travels`).
2. Push these files (`index.html`, `logo.jpeg`, this `README.md`) to the `main` branch.
3. In the repo, go to **Settings → Pages**.
4. Under **Build and deployment**, set **Source** to `Deploy from a branch`, branch `main`, folder `/ (root)`.
5. Save — GitHub will publish the site at `https://<your-username>.github.io/<repo-name>/` within a minute or two.

## Files

- `index.html` — the full page (HTML, CSS, and JS all in one file)
- `logo.jpeg` — the Bade Bhai Travels logo, used in the nav bar and browser tab icon
